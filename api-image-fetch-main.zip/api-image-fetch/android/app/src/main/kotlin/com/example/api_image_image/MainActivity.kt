package com.example.api_image_image

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
